import pandas as pd
from datetime import datetime

# Fichiers d'entrée et de sortie
fichier_entree = "Bonexcel.xlsx"
fichier_sortie = "Bonexcel_fr.xlsx"

# Charger le fichier Excel
df = pd.read_excel(fichier_entree)

# Vérification que les colonnes existent
colonnes_a_convertir = ["datum", "datetime"]
for col in colonnes_a_convertir:
    if col not in df.columns:
        print(f"⚠️  Attention : la colonne '{col}' n'existe pas dans le fichier.")
    else:
        print(f"✅ Colonne '{col}' trouvée.")

# Fonction de conversion en format français JJ/MM/AAAA HH:MM:SS
def convertir_datetime_fr(val):
    if pd.isna(val):
        return val
    try:
        # Si c'est déjà une date/heure
        if isinstance(val, (datetime, pd.Timestamp)):
            return val.strftime("%d/%m/%Y %H:%M:%S")
        else:
            # Essayer de parser une chaîne
            date_parsed = pd.to_datetime(val, errors="coerce")
            if pd.isna(date_parsed):
                return val  # Si non convertible
            return date_parsed.strftime("%d/%m/%Y %H:%M:%S")
    except Exception:
        return val

# Conversion des colonnes
for col in colonnes_a_convertir:
    if col in df.columns:
        df[col] = df[col].apply(convertir_datetime_fr)

# Sauvegarde dans un nouveau fichier Excel
df.to_excel(fichier_sortie, index=False)

print(f"✅ Conversion terminée avec succès !")
print(f"📁 Fichier enregistré sous : {fichier_sortie}")
