# -------------------------------------------------------------
# RUSH 2 — Base master depuis l'horaire (>= 2018) + agrégations
# -------------------------------------------------------------
import pandas as pd
import re
from pathlib import Path

data_dir = Path(__file__).parent
csv_hourly = data_dir / "Pharma_Ventes_Hourly.csv"

# 1) Charger l'horaire (auto-séparateur simple)
hourly = pd.read_csv(csv_hourly, low_memory=False)
hourly.columns = hourly.columns.str.lower().str.strip()

# 2) Construire le timestamp à partir de 'datum' (ex: "1/2/2014 8:00" -> 2014-01-02 08:00)
#    On force "mois/jour/année"
hourly["timestamp"] = pd.to_datetime(
    hourly["datum"], errors="coerce", dayfirst=False, infer_datetime_format=True
)

# 3) Colonnes ATC : m*/n*/r* (exclut "month", "month_name", etc.)
atc_cols = [c for c in hourly.columns if re.match(r"^[mnr]\d", c)]

# 4) Format long
hourly_long = hourly.melt(
    id_vars=["timestamp"], value_vars=atc_cols,
    var_name="category", value_name="qty"
)
hourly_long["qty"] = pd.to_numeric(hourly_long["qty"], errors="coerce").fillna(0)
hourly_long = hourly_long.dropna(subset=["timestamp"])

# 5) Filtre demandé : >= 2018-01-01
hourly_long = hourly_long[hourly_long["timestamp"] >= pd.Timestamp("2018-01-01")]
hourly_long = hourly_long.sort_values("timestamp").reset_index(drop=True)
hourly_long["freq"] = "hourly"

# 6) Agrégations cohérentes
base = hourly_long.set_index("timestamp")
daily   = base.groupby([pd.Grouper(freq="D"),     "category"])["qty"].sum().reset_index().assign(freq="daily")
weekly  = base.groupby([pd.Grouper(freq="W-MON"), "category"])["qty"].sum().reset_index().assign(freq="weekly")
monthly = base.groupby([pd.Grouper(freq="M"),     "category"])["qty"].sum().reset_index().assign(freq="monthly")

# 7) Export multi-feuilles (pour garder les colonnes lisibles)
out_xlsx = data_dir / "Pharma_Ventes_Master_2018plusplus.xlsx"
with pd.ExcelWriter(out_xlsx, engine="openpyxl") as xw:
    hourly_long.to_excel(xw, index=False, sheet_name="hourly")
    daily.to_excel(xw, index=False, sheet_name="daily")
    weekly.to_excel(xw, index=False, sheet_name="weekly")
    monthly.to_excel(xw, index=False, sheet_name="monthly")

print("✅ Export ->", out_xlsx)
for name, df in {"hourly":hourly_long,"daily":daily,"weekly":weekly,"monthly":monthly}.items():
    print(f"{name:7s} | rows={len(df):6d} | {df['timestamp'].min()} → {df['timestamp'].max()} | cats={df['category'].nunique()}")
