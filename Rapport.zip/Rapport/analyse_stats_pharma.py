# -------------------------------------------------------------
# 💊 PHARMA MAX v4 — Analytique complète & autonome (local only)
# - Agrégation journalière (quantités réelles) + analyse horaire
# - Filtrage 23h–6h pour éviter le biais des heures inactives
# - KPIs & stats par catégorie + Totaux globaux
# - YoY, MoM, moyennes glissantes (7j/30j)
# - Heatmaps jour×heure, mois×année, area top 5, Pareto
# - Recommandations : heures & jours d'ouverture, priorités stock
# - Synthèses automatiques (global + par catégorie)
# - Export Excel riche avec 10+ feuilles & 20+ graphiques intégrés
# -------------------------------------------------------------
import os
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from openpyxl import load_workbook
from openpyxl.drawing.image import Image as XLImage
from datetime import timedelta
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)

# ==================== CONFIG ====================
DATA_DIR   = Path(__file__).parent
SOURCE_XLSX = DATA_DIR / "Pharma_Ventes_Transformé.xlsx"
OUTPUT_XLSX = DATA_DIR / "Rapport_Pharma_MAX_v4.xlsx"
IMG_DIR    = DATA_DIR / "_pharma_imgs_v4"
IMG_DIR.mkdir(exist_ok=True)

PREFERRED_SHEETS = ["hourly", "daily", "weekly", "monthly"]
HEURES_VALIDES   = list(range(6, 23))         # conserver 6h→22h
OPEN_THRESHOLD_RATIO = 0.25                   # seuil heures actives = 25% du pic
MIDDAY_WINDOW    = (11, 15)                   # fenêtre midi pour fermeture potentielle
CATS_MAX_BOX     = 20                         # limite lisibilité boxplots

# ==================== HELPERS ====================
def pick_best_sheet(xls):
    for s in PREFERRED_SHEETS:
        if s in xls.sheet_names:
            return s
    return xls.sheet_names[0]

def mois_fr(n):
    return ["jan","fév","mar","avr","mai","juin","juil","aoû","sep","oct","nov","déc"][n-1]

def saison(m):
    if m in (12,1,2):  return "Hiver"
    if m in (3,4,5):   return "Printemps"
    if m in (6,7,8):   return "Été"
    return "Automne"

def savefig(path):
    plt.savefig(path, bbox_inches="tight"); plt.close()

def ensure_dt(s):
    try:
        return pd.to_datetime(s)
    except Exception:
        return s

def median_nonzero(s: pd.Series):
    nz = s[s>0]
    return float(nz.median()) if not nz.empty else 0.0

def fmt_day(s):
    return s.capitalize() if isinstance(s,str) and s else "inconnu"

def add_image(ws, img_path, cell):
    if img_path and Path(img_path).exists():
        ws.add_image(XLImage(str(img_path)), cell)

# ==================== 1) LECTURE & PRÉPA ====================
xls = pd.ExcelFile(SOURCE_XLSX)
SHEET = pick_best_sheet(xls)
df = pd.read_excel(xls, sheet_name=SHEET)

# Normalisation
needed = {"timestamp","category","qty"}
miss = needed - set(df.columns)
if miss:
    raise ValueError(f"Colonnes manquantes dans '{SHEET}': {miss}")

df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
df["qty"] = pd.to_numeric(df["qty"], errors="coerce").fillna(0)
df = df.dropna(subset=["timestamp"]).copy()

# Dimensions
df["Année"]  = df["timestamp"].dt.year
df["Mois"]   = df["timestamp"].dt.month
df["Mois_nom"] = df["Mois"].apply(mois_fr)
df["Jour"]   = df["timestamp"].dt.day
df["Heure"]  = df["timestamp"].dt.hour
day_map = {0:"lundi",1:"mardi",2:"mercredi",3:"jeudi",4:"vendredi",5:"samedi",6:"dimanche"}
df["JourSemaine"] = df["timestamp"].dt.dayofweek.map(day_map)
df["Saison"] = df["Mois"].apply(saison)

IS_HOURLY = (SHEET.lower()=="hourly")

# ==================== 2) FILTRAGE 23h–6h (si hourly) ====================
if IS_HOURLY:
    before = len(df)
    df = df[df["Heure"].isin(HEURES_VALIDES)].copy()
    print(f"[Filtrage horaire] Retiré {before-len(df)} lignes (23h→6h). Restant: {len(df)}.")

# ==================== 3) AGRÉGATION JOURNALIÈRE (quantités réelles) ====================
df_day = (
    df.groupby([df["timestamp"].dt.date, "category"])["qty"].sum()
      .reset_index().rename(columns={"timestamp":"date"})
)
df_day["date"] = pd.to_datetime(df_day["date"])
df_day["Année"] = df_day["date"].dt.year
df_day["Mois"]  = df_day["date"].dt.month
df_day["JourSemaine"] = df_day["date"].dt.dayofweek.map(day_map)
nb_jours_total = df_day["date"].nunique()

# ==================== 4) STATS — PAR CATÉGORIE & GLOBAL ====================
stats_cat = (
    df_day.groupby("category")["qty"]
      .agg(Nb_jours="count", Total_ventes="sum",
           Moyenne_jour="mean", Médiane_jour="median",
           Médiane_hors_zeros=lambda s: median_nonzero(s),
           Écart_type="std", Min="min", Max="max")
      .reset_index()
)
# Jours actifs & indicateurs
jours_actifs = df_day.groupby("category").apply(lambda d: int((d["qty"]>0).sum())).rename("Jours_actifs")
stats_cat = stats_cat.merge(jours_actifs, on="category", how="left")
stats_cat["Taux_activité_%"] = (stats_cat["Jours_actifs"]/nb_jours_total*100).round(2)
intensite = df_day[df_day["qty"]>0].groupby("category")["qty"].mean().rename("Intensité_moyenne")
stats_cat = stats_cat.merge(intensite, on="category", how="left")
stats_cat["Coeff_variation_%"] = np.where(
    stats_cat["Moyenne_jour"]!=0, (stats_cat["Écart_type"]/stats_cat["Moyenne_jour"])*100, np.nan
).round(2)
stats_cat["Rang_volume"] = stats_cat["Total_ventes"].rank(ascending=False, method="dense").astype(int)

# GLOBAL
stats_global = pd.DataFrame({
    "Indicateur": ["Total ventes (pharmacie)", "Jours analysés",
                   "Moyenne/jour (global)", "Médiane/jour (global)",
                   "Écart-type/jour (global)"],
    "Valeur": [
        df_day["qty"].sum(),
        nb_jours_total,
        df_day.groupby("date")["qty"].sum().mean(),
        df_day.groupby("date")["qty"].sum().median(),
        df_day.groupby("date")["qty"].sum().std()
    ]
})

# ==================== 5) TEMPS — MENSUEL / JOUR / HEURE / SAISON ====================
# Mensuel par catégorie + Total
monthly_cat = df_day.groupby(["Année","Mois","category"])["qty"].sum().reset_index()
monthly_total = df_day.groupby(["Année","Mois"])["qty"].sum().reset_index().assign(category="Total")
monthly_full  = pd.concat([monthly_cat, monthly_total], ignore_index=True)

# Jours semaine
weekday_cat = df_day.groupby(["JourSemaine","category"])["qty"].mean().reset_index()
weekday_total = df_day.groupby("JourSemaine")["qty"].mean().reset_index().assign(category="Total")
weekday_full = pd.concat([weekday_cat, weekday_total], ignore_index=True)

# Horaire (depuis df horaire filtré → moyenne par heure)
if IS_HOURLY:
    hour_cat = df.groupby(["Heure","category"])["qty"].mean().reset_index()
    hour_total = df.groupby("Heure")["qty"].mean().reset_index().assign(category="Total")
    hour_full = pd.concat([hour_cat, hour_total], ignore_index=True)
else:
    hour_full = pd.DataFrame()
    hour_total = pd.DataFrame()

# Saisons
season_cat = df_day.copy()
season_cat["Saison"] = season_cat["Mois"].apply(saison)
season_cat = season_cat.groupby(["Saison","category"])["qty"].mean().reset_index()
season_total = df_day.copy()
season_total["Saison"] = season_total["Mois"].apply(saison)
season_total = season_total.groupby("Saison")["qty"].mean().reset_index().assign(category="Total")
season_full = pd.concat([season_cat, season_total], ignore_index=True)

# ==================== 6) COMPARAISONS — YoY & MoM & Moving Averages ====================
# YoY par catégorie
yoy = df_day.pivot_table(values="qty", index="category", columns="Année", aggfunc="sum", fill_value=0)
yoy = yoy.reset_index()
years = [c for c in yoy.columns if isinstance(c,(int,np.integer))]
if len(years)>=2:
    base, last = min(years), max(years)
    yoy["Croissance_%"] = np.where(yoy[base]==0, np.nan, (yoy[last]-yoy[base])/yoy[base]*100)

# MoM global
df_day["YearMonth"] = df_day["date"].dt.to_period("M")
mom = df_day.groupby("YearMonth")["qty"].sum().reset_index()

# ✅ Conversion correcte vers timestamp
mom["date_ts"] = mom["YearMonth"].dt.to_timestamp()

# Calcul du MoM (%)
mom["MoM_%"] = mom["qty"].pct_change() * 100


# Moving averages (global)
daily_total = df_day.groupby("date")["qty"].sum().reset_index().sort_values("date")
daily_total["MA7"]  = daily_total["qty"].rolling(7, min_periods=1).mean()
daily_total["MA30"] = daily_total["qty"].rolling(30, min_periods=1).mean()

# ==================== 7) RECOMMANDATIONS ====================
# Jours d’ouverture (sur total)
wd_order = ["lundi","mardi","mercredi","jeudi","vendredi","samedi","dimanche"]
wd_tot = weekday_total.set_index("JourSemaine").reindex(wd_order)["qty"]
best_day = fmt_day(wd_tot.idxmax()) if wd_tot.notna().any() else "inconnu"
worst_day = fmt_day(wd_tot.idxmin()) if wd_tot.notna().any() else "inconnu"

# Heures (si hourly)
if IS_HOURLY and not hour_total.empty:
    ht = hour_total.set_index("Heure")["qty"]
    peak = float(ht.max()) if ht.notna().any() else 0.0
    thr  = OPEN_THRESHOLD_RATIO*peak
    active = ht[ht>thr]
    open_hour  = int(active.index.min()) if not active.empty else 9
    close_hour = int(active.index.max()) if not active.empty else 19
    # fermeture midi potentielle
    mstart, mend = MIDDAY_WINDOW
    mids = [h for h in range(mstart,mend) if h in ht.index and ht[h]<thr]
    # run le plus long
    best_run, run = [], []
    for h in range(mstart,mend):
        if h in mids:
            run.append(h)
            if len(run)>len(best_run): best_run=run[:]
        else:
            run=[]
    midday_closure = (best_run[0], best_run[-1]+1) if len(best_run)>=2 else None
else:
    open_hour, close_hour, midday_closure = 9, 19, None

# Produits priorités & watchlist (stabilité/volume)
vol_mean = stats_cat["Total_ventes"].mean()
cv_med   = stats_cat["Coeff_variation_%"].median(skipna=True)
priorites = stats_cat[(stats_cat["Total_ventes"]>vol_mean) & (stats_cat["Coeff_variation_%"]<=cv_med)]
priorites_list = priorites.sort_values("Total_ventes", ascending=False)["category"].head(10).tolist()

watch = stats_cat[(stats_cat["Total_ventes"]>=stats_cat["Total_ventes"].quantile(0.25)) &
                  (stats_cat["Coeff_variation_%"]>=stats_cat["Coeff_variation_%"].quantile(0.75))]
watch_list = watch.sort_values("Coeff_variation_%", ascending=False)["category"].head(5).tolist()

# ==================== 8) SYNTHÈSES TEXTE ====================
synthese_global = f"""SYNTHÈSE AUTOMATIQUE — PHARMA MAX v4
------------------------------------------------
Feuille analysée : {SHEET}
Période : {df_day['Année'].min()} → {df_day['Année'].max()}
Jours analysés : {nb_jours_total}
Total ventes (toutes catégories) : {df_day['qty'].sum():,.0f} unités

🕒 Heures recommandées : {open_hour:02d}h–{close_hour:02d}h
{('🌙 Fermeture midi recommandée : ' + str(midday_closure[0]).zfill(2) + 'h–' + str(midday_closure[1]).zfill(2) + 'h') if midday_closure else '🌙 Fermeture midi : non détectée / non conseillée'}

📅 Jour le plus rentable : {best_day}
📉 Jour le plus calme   : {worst_day}

💊 Priorités stock (volume haut & stabilité) :
{', '.join(priorites_list) if priorites_list else '—'}

⚠️ Watchlist (volatiles à surveiller) :
{', '.join(watch_list) if watch_list else '—'}
"""

# Synthèse par catégorie (top 8)
def synthese_cat_row(r):
    return (f"- {r['category']}: total {r['Total_ventes']:.0f}, médiane/jour {r['Médiane_jour']:.1f}, "
            f"activité {r['Taux_activité_%']:.1f}%, intensité {0 if pd.isna(r['Intensité_moyenne']) else r['Intensité_moyenne']:.1f}, "
            f"CV% {0 if pd.isna(r['Coeff_variation_%']) else r['Coeff_variation_%']:.1f}")

top8 = stats_cat.sort_values("Total_ventes", ascending=False).head(8)
synthese_cats = "SYNTHÈSE PAR CATÉGORIE (Top 8)\n" + "\n".join([synthese_cat_row(r) for _,r in top8.iterrows()])

# ==================== 9) GRAPHIQUES (20+) ====================
sns.set_theme(style="whitegrid")

def p(name): return str(IMG_DIR / f"{name}.png")

imgs = []

# 1 Top 15 catégories
plt.figure(figsize=(11,6))
top15 = stats_cat.sort_values("Total_ventes", ascending=False).head(15)
sns.barplot(x="category", y="Total_ventes", data=top15)
plt.xticks(rotation=45); plt.title("Top 15 catégories — Total ventes")
savefig(p("01_top15")); imgs.append(p("01_top15"))

# 2 Parts de marché (top 10)
plt.figure(figsize=(6,6))
labels = top15["category"].head(10)
sizes  = top15["Total_ventes"].head(10).values
plt.pie(sizes, labels=labels, autopct="%1.1f%%", startangle=90)
plt.title("Parts de marché (Top 10)")
savefig(p("02_pie")); imgs.append(p("02_pie"))

# 3 Pareto
pareto = stats_cat.sort_values("Total_ventes", ascending=False).copy()
pareto["cum%"] = pareto["Total_ventes"].cumsum()/pareto["Total_ventes"].sum()*100
fig, ax1 = plt.subplots(figsize=(11,6))
ax1.bar(pareto["category"], pareto["Total_ventes"]); ax1.tick_params(axis="x", rotation=45)
ax2 = ax1.twinx(); ax2.plot(pareto["category"], pareto["cum%"], color="black", marker="o")
ax1.set_title("Pareto catégories (80/20)"); ax1.set_ylabel("Total"); ax2.set_ylabel("Cumul %")
savefig(p("03_pareto")); imgs.append(p("03_pareto"))

# 4 Distribution journalière
plt.figure(figsize=(8,5))
plt.hist(df_day["qty"], bins=40); plt.title("Distribution des ventes quotidiennes (toutes catégories)")
plt.xlabel("Quantité / jour"); plt.ylabel("Fréquence")
savefig(p("04_hist")); imgs.append(p("04_hist"))

# 5 Boxplot (Top 20 pour lisibilité)
cats20 = stats_cat.sort_values("Total_ventes", ascending=False)["category"].head(CATS_MAX_BOX).tolist()
df_box = df_day[df_day["category"].isin(cats20)]
if not df_box.empty:
    plt.figure(figsize=(12,6))
    sns.boxplot(x="category", y="qty", data=df_box)
    plt.xticks(rotation=45); plt.title("Variabilité par catégorie (Top 20)")
    savefig(p("05_box")); imgs.append(p("05_box"))

# 6 Scatter Moyenne_jour vs Écart_type (taille=volume)
plt.figure(figsize=(8,6))
sizes = (stats_cat["Total_ventes"]/stats_cat["Total_ventes"].max()*400).clip(30,400)
plt.scatter(stats_cat["Moyenne_jour"], stats_cat["Écart_type"], s=sizes)
plt.xlabel("Moyenne/jour"); plt.ylabel("Écart-type/jour"); plt.title("Moyenne vs Écart-type — taille=volume")
savefig(p("06_scatter")); imgs.append(p("06_scatter"))

# 7 Évolution mensuelle TOTAL par année
plt.figure(figsize=(10,6))
for an, sub in monthly_total.groupby("Année"):
    sub = sub.sort_values("Mois")
    plt.plot(sub["Mois"], sub["qty"], marker="o", label=str(an))
plt.title("Évolution mensuelle (TOTAL)"); plt.xlabel("Mois"); plt.ylabel("Ventes"); plt.legend()
savefig(p("07_mens_total")); imgs.append(p("07_mens_total"))

# 8 Heatmap Mois×Année (TOTAL)
heat = df_day.groupby([df_day["date"].dt.month, df_day["date"].dt.year])["qty"].sum().unstack().fillna(0)
plt.figure(figsize=(10,6))
sns.heatmap(heat, cmap="YlGnBu", annot=True, fmt=".0f"); plt.title("Saisonnalité — Mois × Année (TOTAL)")
plt.ylabel("Mois"); plt.xlabel("Année")
savefig(p("08_heat_mois_annee")); imgs.append(p("08_heat_mois_annee"))

# 9 Bar jours semaine (TOTAL)
plt.figure(figsize=(8,5))
wd_tot.plot(kind="bar", color="teal"); plt.title("Moyenne journalière par jour (TOTAL)"); plt.ylabel("Ventes moyennes")
savefig(p("09_weekday_total")); imgs.append(p("09_weekday_total"))

# 10 Profil horaire TOTAL (si hourly)
if IS_HOURLY and not hour_total.empty:
    plt.figure(figsize=(9,5))
    ht = hour_total.set_index("Heure")["qty"]
    plt.plot(ht.index, ht.values, marker="o"); plt.title("Profil horaire moyen (TOTAL)")
    plt.xlabel("Heure"); plt.ylabel("Ventes moyennes")
    savefig(p("10_hour_total")); imgs.append(p("10_hour_total"))

# 11 Saisons — TOTAL
st = season_total.set_index("Saison")["qty"]
plt.figure(figsize=(8,5))
st.loc[["Hiver","Printemps","Été","Automne"]].plot(kind="bar")
plt.title("Ventes moyennes par saison (TOTAL)"); plt.ylabel("Moyenne/jour")
savefig(p("11_saisons_total")); imgs.append(p("11_saisons_total"))

# 12 Cumul ventes
cum = daily_total.copy(); cum["cum"] = cum["qty"].cumsum()
plt.figure(figsize=(10,5))
plt.plot(cum["date"], cum["cum"]); plt.title("Cumul des ventes (TOTAL)")
plt.xlabel("Date"); plt.ylabel("Cumul")
savefig(p("12_cumul")); imgs.append(p("12_cumul"))

# 13 MoM
plt.figure(figsize=(10,5))
x = ensure_dt(mom["date_ts"])
plt.plot(x, mom["qty"], marker="o", label="Ventes")
ax = plt.gca().twinx(); ax.plot(x, mom["MoM_%"], linestyle="--", color="gray", label="MoM %")
plt.title("Évolution & MoM (TOTAL)"); plt.legend(loc="upper left")
savefig(p("13_mom")); imgs.append(p("13_mom"))

# 14 MA 7/30
plt.figure(figsize=(10,5))
plt.plot(daily_total["date"], daily_total["qty"], alpha=0.4, label="Quotidien")
plt.plot(daily_total["date"], daily_total["MA7"], label="MA 7j")
plt.plot(daily_total["date"], daily_total["MA30"], label="MA 30j")
plt.title("Tendances glissantes (7j/30j)"); plt.legend()
savefig(p("14_ma")); imgs.append(p("14_ma"))

# 15 Heatmap jour×heure (si hourly)
if IS_HOURLY:
    jh = df.groupby(["JourSemaine","Heure"])["qty"].mean().unstack().reindex(wd_order)
    plt.figure(figsize=(12,5))
    sns.heatmap(jh, cmap="mako", annot=False); plt.title("Heatmap Jour × Heure (moyenne)")
    savefig(p("15_heat_jour_heure")); imgs.append(p("15_heat_jour_heure"))

# 16 Area Top 5 (mois ordonnés)
top5 = stats_cat.sort_values("Total_ventes", ascending=False)["category"].head(5).tolist()
area = monthly_cat[monthly_cat["category"].isin(top5)].copy()
area["key"] = area["Année"].astype(str)+"-"+area["Mois"].astype(str).str.zfill(2)
pv = area.pivot_table(index="key", columns="category", values="qty", aggfunc="sum").fillna(0)
plt.figure(figsize=(11,6))
plt.stackplot(range(len(pv.index)), *[pv[c].values for c in pv.columns], labels=pv.columns)
plt.legend(loc="upper left"); plt.title("Top 5 catégories — area (mois ordonnés)")
savefig(p("16_area_top5")); imgs.append(p("16_area_top5"))

# 17 YoY bar (si au moins 2 ans)
if len(years)>=2:
    yoy_plot = yoy.set_index("category")[[years[0], years[-1]]].sort_values(years[-1], ascending=False).head(12)
    plt.figure(figsize=(10,6))
    yoy_plot.plot(kind="bar"); plt.title(f"YoY par catégorie — {years[0]} vs {years[-1]}")
    plt.xticks(rotation=45); plt.ylabel("Total")
    savefig(p("17_yoy")); imgs.append(p("17_yoy"))

# 18 Intégralité ventes quotidiennes (boîte violon globale)
plt.figure(figsize=(6,5))
sns.violinplot(y=df_day["qty"], inner="quartile"); plt.title("Distribution journalière globale (violin)")
savefig(p("18_violin_global")); imgs.append(p("18_violin_global"))

# 19 Top vs Bottom (5) — bar côte à côte
top5v = stats_cat.sort_values("Total_ventes", ascending=False).head(5)[["category","Total_ventes"]]
bot5v = stats_cat.sort_values("Total_ventes", ascending=True).head(5)[["category","Total_ventes"]]
fig, axes = plt.subplots(1,2, figsize=(12,5))
sns.barplot(x="category", y="Total_ventes", data=top5v, ax=axes[0]); axes[0].set_title("Top 5 (Total)")
axes[0].tick_params(axis="x", rotation=45)
sns.barplot(x="category", y="Total_ventes", data=bot5v, ax=axes[1]); axes[1].set_title("Bottom 5 (Total)")
axes[1].tick_params(axis="x", rotation=45)
savefig(p("19_top_bottom")); imgs.append(p("19_top_bottom"))

# 20 Taux d’activité (%)
plt.figure(figsize=(10,5))
sns.barplot(x="category", y="Taux_activité_%", data=stats_cat.sort_values("Taux_activité_%", ascending=False))
plt.xticks(rotation=45); plt.title("Taux d’activité (%) par catégorie")
savefig(p("20_activity")); imgs.append(p("20_activity"))

# ==================== 10) EXPORT EXCEL ====================
with pd.ExcelWriter(OUTPUT_XLSX, engine="openpyxl") as writer:
    # README
    pd.DataFrame({
        "Clé": ["Feuille analysée", "Période min", "Période max", "Lignes brutes", "Lignes après filtre", "Jours analysés", "Catégories"],
        "Valeur": [SHEET, str(df["timestamp"].min()), str(df["timestamp"].max()), None, len(df), nb_jours_total, df["category"].nunique()]
    }).to_excel(writer, index=False, sheet_name="README")
    # Stats
    stats_global.to_excel(writer, index=False, sheet_name="Stats_GLOBAL")
    stats_cat.to_excel(writer, index=False, sheet_name="Stats_par_catégorie")
    # Temps (CAT + TOTAL)
    monthly_full.to_excel(writer, index=False, sheet_name="Mensuel_CAT+TOTAL")
    weekday_full.to_excel(writer, index=False, sheet_name="Jours_CAT+TOTAL")
    season_full.to_excel(writer, index=False, sheet_name="Saisons_CAT+TOTAL")
    if not hour_full.empty:
        hour_full.to_excel(writer, index=False, sheet_name="Heures_CAT+TOTAL")
    # Comparaisons & tendances
    yoy.to_excel(writer, index=False, sheet_name="YoY_catégories")
    mom[["date_ts","qty","MoM_%"]].rename(columns={"date_ts":"date"}).to_excel(writer, index=False, sheet_name="MoM_total")
    daily_total.to_excel(writer, index=False, sheet_name="Tendances_MA")

# Ajout Synthèses + Graphiques
wb = load_workbook(OUTPUT_XLSX)
ws = wb.create_sheet("Synthèse & Graphiques")
ws["A1"] = synthese_global
ws["A12"] = synthese_cats

row = 20
for img in imgs:
    add_image(ws, img, f"A{row}")
    row += 22

wb.save(OUTPUT_XLSX)
print(f"✅ Rapport généré : {OUTPUT_XLSX}")
print(f"🖼️ Graphiques : {IMG_DIR}")
