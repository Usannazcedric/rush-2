import pandas as pd
from pathlib import Path

# 1) Charger le fichier source
src = Path("Pharma_Ventes_Hourly.csv")

df = pd.read_csv(src, low_memory=False)

# 2) Parser correctement la date (format US : month/day/year)
df["datetime"] = pd.to_datetime(df["datum"], dayfirst=False, errors="coerce")

# 3) Colonnes de ventes (codes ATC)
cols_atc = ["M01AB", "M01AE", "N02BA", "N02BE", "N05B", "N05C", "R03", "R06"]

# 4) Passage au format long
df_long = df.melt(
    id_vars=["datum", "Year", "Month", "Hour", "Weekday Name", "datetime"],
    value_vars=cols_atc,
    var_name="Code_ATC",
    value_name="Quantite"
)

# 5) Tri (8 lignes par heure, triées par code)
df_long = df_long.sort_values(["datetime", "Code_ATC"]).reset_index(drop=True)

# 6) Export en fichier Excel
output = Path("Pharma_Ventes_Hourly_long.xlsx")
df_long.to_excel(output, index=False, engine="openpyxl")

print("✅ Fichier Excel exporté :", output)
print(f" - Lignes : {len(df_long):,}")
print(f" - Colonnes : {len(df_long.columns)}")
print(" - 8 codes ATC par heure, format long OK")
