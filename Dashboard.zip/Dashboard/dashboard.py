import pandas as pd

# Fichier d'entrée et sortie
fichier_entree = "Bonexcel.xlsx"
fichier_sortie = "Dashboard.xlsx"

# Charger les données
df = pd.read_excel(fichier_entree)

# Conversion des colonnes de date si nécessaire
for col in ["datum", "datetime"]:
    if col in df.columns:
        df[col] = pd.to_datetime(df[col], errors="coerce")

# Créer un tableau croisé dynamique de base (à adapter selon tes colonnes)
# Exemple : Somme d'une colonne "montant" par catégorie et date
if "category" in df.columns and "montant" in df.columns:
    pivot = pd.pivot_table(
        df,
        index=["category"],
        columns=[df["datum"].dt.date],
        values="montant",
        aggfunc="sum",
        fill_value=0
    )
else:
    # Si tu n’as pas encore les colonnes 'category' et 'montant', on crée un exemple générique
    pivot = df

# Sauvegarde avec xlsxwriter (pour les slicers et mise en forme)
with pd.ExcelWriter(fichier_sortie, engine="xlsxwriter") as writer:
    df.to_excel(writer, sheet_name="Données", index=False)
    pivot.to_excel(writer, sheet_name="Dashboard")

    # Accès au classeur et à la feuille
    workbook = writer.book
    worksheet = writer.sheets["Dashboard"]

    # Formater un peu le tableau
    format_titre = workbook.add_format({'bold': True, 'bg_color': '#DCE6F1'})
    worksheet.set_row(0, None, format_titre)
    worksheet.autofilter(0, 0, len(pivot), len(pivot.columns))

    # (Optionnel) Créer un graphique dynamique
    chart = workbook.add_chart({'type': 'column'})
    chart.add_series({
        'categories': ['Dashboard', 1, 0, len(pivot), 0],
        'values':     ['Dashboard', 1, 1, len(pivot), 1],
        'name':       'Montant total'
    })
    chart.set_title({'name': 'Montants par catégorie'})
    worksheet.insert_chart('J2', chart)

print(f"✅ Dashboard créé avec succès dans le fichier : {fichier_sortie}")
